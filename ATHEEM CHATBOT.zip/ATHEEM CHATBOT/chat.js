const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');

function appendMessage(sender, text) {
  const msg = document.createElement('div');
  msg.className = sender;
  msg.innerHTML = text;
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

appendMessage('bot', `Karibu kwenye ATHEEM CHATBOT! 💬 <br> Jiunge na channel yetu: <a href="https://whatsapp.com/channel/0029VbASXujBlHpZCC7il50J" target="_blank">ATHEEM WhatsApp Channel</a>`);

sendBtn.addEventListener('click', async () => {
  const message = userInput.value.trim();
  if(!message) return;
  appendMessage('user', message);
  userInput.value = '';

  const res = await fetch('/chat', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({message})
  });
  const data = await res.json();
  appendMessage('bot', data.reply);
});