import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('.')); // serve index.html

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.post('/chat', async (req, res) => {
  const { message } = req.body;
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{role: "user", content: message}],
    });
    res.json({reply: response.choices[0].message.content});
  } catch (err) {
    res.json({reply: "Samahani, kuna tatizo. Jaribu tena."});
  }
});

app.listen(process.env.PORT || 3000, () => console.log('Server running'));